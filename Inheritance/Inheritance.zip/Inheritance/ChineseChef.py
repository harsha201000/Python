from Chef import Chef

class ChineseChef(Chef):
    
    def make_special_dish(self):
        print("Chef makes orange chicken")
    
    def make_fried_rice(self):
        print("The chef makes fried rice")

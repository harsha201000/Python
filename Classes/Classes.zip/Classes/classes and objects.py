from Car import Car

car_1 = (Car("Acura","RDX",2019,"dark grey"))
car_2 = (Car("Honda","Accord",2011,"dark red"))

car_2.drive()
car_2.stop()